<h2 class="card-title">C. Data Orang Tua</h2>
<div class="mb-3 row">
    <label class="col-sm-2 col-form-label">Nama Ayah</label>
    <div class="col-sm-10">
    <input type="text" class="form-control" value="<?php echo @$edit['nama_ayah'] ?>" disabled>
    </div>
</div>
<div class="mb-3 row">
    <label class="col-sm-2 col-form-label">Pekerjaan Ayah</label>
    <div class="col-sm-10">
    <input type="text" class="form-control" value="<?php echo @$edit['pekerjaan_ayah'] ?>" disabled>
    </div>
</div>
<div class="mb-3 row">
    <label class="col-sm-2 col-form-label">Nama Ibu</label>
    <div class="col-sm-10">
    <input type="text" class="form-control" value="<?php echo @$edit['nama_ibu'] ?>" disabled>
    </div>
</div>
<div class="mb-3 row">
    <label class="col-sm-2 col-form-label">Pekerjaan Ibu</label>
    <div class="col-sm-10">
    <input type="text" class="form-control" value="<?php echo @$edit['pekerjaan_ibu'] ?>" disabled>
    </div>
</div>
<hr>