<h2 class="card-title">A. Data Pribadi</h2>
<div class="mb-3 row">
    <label class="col-sm-2 col-form-label">Nomor Induk Keluarga</label>
    <div class="col-sm-10">
    <input type="text" class="form-control" value="<?php echo @$edit['NIK'] ?>" disabled>
    </div>
</div>
<div class="mb-3 row">
    <label class="col-sm-2 col-form-label">Nama Lengkap</label>
    <div class="col-sm-10">
    <input type="text" class="form-control" value="<?php echo @$edit['nama_lengkap'] ?>" disabled>
    </div>
</div>
<div class="mb-3 row">
    <label class="col-sm-2 col-form-label">Jenis Kelamin</label>
    <div class="col-sm-10">
    <input type="text" class="form-control" value="<?php echo @$edit['NIK'] ?>" disabled>
    </div>
</div>
<div class="mb-3 row">
    <label class="col-sm-2 col-form-label">Tempat / Tanggal Lahir</label>
    <div class="col-sm-10">
    <input type="text" class="form-control" value="<?php echo @$edit['tempat_lahir'] . ", " . @$edit['tanggal_lahir']; ?>" disabled>
    </div>
</div>
<div class="mb-3 row">
    <label class="col-sm-2 col-form-label">Jenis Kelamin</label>
    <div class="col-sm-10">
    <input type="text" class="form-control" value="<?php echo @$edit['NIK'] ?>" disabled>
    </div>
</div>
<div class="mb-3 row">
    <label class="col-sm-2 col-form-label">Agama</label>
    <div class="col-sm-10">
    <input type="text" class="form-control" value="<?php echo @$edit['agama'] ?>" disabled>
    </div>
</div>
<div class="mb-3 row">
    <label class="col-sm-2 col-form-label">Cita - cita</label>
    <div class="col-sm-10">
    <input type="text" class="form-control" value="<?php echo @$edit['cita_cita'] ?>" disabled>
    </div>
</div>
<div class="mb-3 row">
    <label class="col-sm-2 col-form-label">Jumlah Saudara</label>
    <div class="col-sm-10">
    <input type="text" class="form-control" value="<?php echo @$edit['jumlah_saudara'] ?>" disabled>
    </div>
</div>
<div class="mb-3 row">
    <label class="col-sm-2 col-form-label">Berat Badan</label>
    <div class="col-sm-10">
    <input type="text" class="form-control" value="<?php echo @$edit['berat_badan'] ?>" disabled>
    </div>
</div>
<div class="mb-3 row">
    <label class="col-sm-2 col-form-label">Tinggi Badan</label>
    <div class="col-sm-10">
    <input type="text" class="form-control" value="<?php echo @$edit['tinggi_badan'] ?>" disabled>
    </div>
</div>
<div class="mb-3 row">
    <label class="col-sm-2 col-form-label">Golongan Darah</label>
    <div class="col-sm-10">
    <input type="text" class="form-control" value="<?php echo @$edit['golongan_darah'] ?>" disabled>
    </div>
</div>
<hr>