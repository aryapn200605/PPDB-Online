<h2 class="card-title">C. Data Orang Tua</h2>
<div class="mb-3 row">
    <label class="col-sm-2 col-form-label">Nama Ayah</label>
    <div class="col-sm-10">
    <input type="text" name="nama_ayah" class="form-control text-capitalize" placeholder="Nama Ayah" required>
    </div>
</div>
<div class="mb-3 row">
    <label class="col-sm-2 col-form-label">Pekerjaan Ayah</label>
    <div class="col-sm-10">
    <input type="text" name="pekerjaan_ayah" class="form-control text-capitalize" placeholder="Pekerjaan Ayah" required>
    </div>
</div>
<div class="mb-3 row">
    <label class="col-sm-2 col-form-label">Nama Ibu</label>
    <div class="col-sm-10">
    <input type="text" name="nama_ibu" class="form-control text-capitalize" placeholder="Nama Ibu" required>
    </div>
</div>
<div class="mb-3 row">
    <label class="col-sm-2 col-form-label">Pekerjaan Ibu</label>
    <div class="col-sm-10">
    <input type="text" name="pekerjaan_ibu" class="form-control text-capitalize" placeholder="Pekerjaan Ibu" required>
    </div>
</div>
<hr>