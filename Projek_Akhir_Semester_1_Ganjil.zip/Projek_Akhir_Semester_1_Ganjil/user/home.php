
          <div class="col-md-12">
            <h4>Dashboard</h4>
          </div>
          <div class="col-md-12">
            <p>Selamat datang di sistem Penerimaan Peserta Didik Baru SMK Wikrama 1 Garut</p>
            <br>Panduan Pendaftaran:
            <br>1. Pada bagian menu, klik 'Pendaftaran'.
            <br>2. Isi seluruh formulir yang ditampilkan kemudian periksa kembali, pastikan tidak ada data yang salah.
            <br>3. Klik submit, kemudian klik Confirm. Setelah di-confirm, data tidak dapat diubah kembali.
            <br>4. Jika sudah, bukti pendaftaran akan ditampilkan
            <br>5. Jika sudah, maka status akan tertulis "verified"
            <br>6. Jika pengumuman penerimaan telah masuk maka status akan berubah menjadi Diterima/Ditolak
            <br>7. Pengumuman penerimaan dapat dilihat di daftar peserta
            <br>
            <br>*Note: Pihak sekolah baru akan menerima data Anda setelah Anda klik 'Confirm'
          </div>